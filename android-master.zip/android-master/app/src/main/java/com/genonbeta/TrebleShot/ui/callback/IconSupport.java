package com.genonbeta.TrebleShot.ui.callback;

import androidx.annotation.DrawableRes;

/**
 * created by: veli
 * date: 9/3/18 11:13 PM
 */
public interface IconSupport
{
    @DrawableRes
    int getIconRes();
}
