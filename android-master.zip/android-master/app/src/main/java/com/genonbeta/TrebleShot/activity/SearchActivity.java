package com.genonbeta.TrebleShot.activity;

import com.genonbeta.TrebleShot.app.Activity;

public class SearchActivity extends Activity
{
}
