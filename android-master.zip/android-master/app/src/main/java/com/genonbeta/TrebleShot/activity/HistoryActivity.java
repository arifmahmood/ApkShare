package com.genonbeta.TrebleShot.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.genonbeta.TrebleShot.R;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
    }
}
