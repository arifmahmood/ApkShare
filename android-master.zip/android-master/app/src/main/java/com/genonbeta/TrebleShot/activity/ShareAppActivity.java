package com.genonbeta.TrebleShot.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Toast;

import com.genonbeta.TrebleShot.R;
import com.genonbeta.TrebleShot.config.AppConfig;
import com.genonbeta.TrebleShot.util.FileUtils;
import com.genonbeta.android.framework.io.DocumentFile;
import com.genonbeta.android.framework.util.Interrupter;

import java.io.File;

public class ShareAppActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_app);

        findViewById(R.id.shareAsApk).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareAsApk(ShareAppActivity.this);
            }
        });
        findViewById(R.id.shareAsLink).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareAsLink(ShareAppActivity.this);
            }
        });
    }

    private void shareAsApk(@NonNull final Context context)
    {
        new Handler(Looper.myLooper()).post(new Runnable()
        {
            @Override
            public void run()
            {
                try {
                    Interrupter interrupter = new Interrupter();

                    PackageManager pm = context.getPackageManager();
                    PackageInfo packageInfo = pm.getPackageInfo(context.getApplicationInfo().packageName, 0);

                    String fileName = packageInfo.applicationInfo.loadLabel(pm) + "_" + packageInfo.versionName + ".apk";

                    DocumentFile storageDirectory = FileUtils.getApplicationDirectory(context.getApplicationContext());
                    DocumentFile codeFile = DocumentFile.fromFile(new File(context.getApplicationInfo().sourceDir));
                    DocumentFile cloneFile = storageDirectory.createFile(null, FileUtils.getUniqueFileName(storageDirectory, fileName, true));

                    FileUtils.copy(context, codeFile, cloneFile, interrupter);

                    try {
                        Intent sendIntent = new Intent(Intent.ACTION_SEND)
                                .putExtra(ShareActivity.EXTRA_FILENAME_LIST, fileName)
                                .putExtra(Intent.EXTRA_STREAM, FileUtils.getSecureUri(context, cloneFile))
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                .setType(cloneFile.getType());

                        context.startActivity(Intent.createChooser(sendIntent, context.getString(R.string.text_fileShareAppChoose)));
                    } catch (IllegalArgumentException e) {
                        Toast.makeText(context, R.string.mesg_providerNotAllowedError, Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    private void shareAsLink(@NonNull final Context context)
    {
        new Handler(Looper.myLooper()).post(new Runnable()
        {
            @Override
            public void run()
            {
                try {
                    String textToShare = context.getString(R.string.text_linkTrebleshot,
                            AppConfig.URI_GOOGLE_PLAY);

                    Intent sendIntent = new Intent(Intent.ACTION_SEND)
                            .putExtra(Intent.EXTRA_TEXT, textToShare)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            .setType("text/plain");

                    context.startActivity(Intent.createChooser(sendIntent, context.getString(R.string.text_fileShareAppChoose)));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

}
