package com.genonbeta.TrebleShot.exception;

/**
 * created by: veli
 * date: 06.04.2018 11:20
 */
public class AssigneeNotFoundException extends Exception
{
}
