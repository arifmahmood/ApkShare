package com.genonbeta.TrebleShot.activity;

import com.genonbeta.TrebleShot.app.Activity;

public class ShareTextActivity extends Activity
{
}
